package com.desipal.eventu.Presentacion;

public interface Item {

    public boolean isSection();

}
